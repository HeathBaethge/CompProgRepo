﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace HBaethgeACP2_1
{
    public partial class frmInputOutput : Form
    {
        StreamReader stread = new StreamReader("numbers.txt");
        StreamWriter stwrite = new StreamWriter("grades.txt");
        double[] nums = new double[6];
        char[] letGrade = new char[6];
        double total = 0, avg = 0;
        char letAvg;

        public frmInputOutput()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnGrades_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < nums.Length; i++)
            {
                total += nums[i];

                if (nums[i] >= 90)
                {
                    letGrade[i] = 'A';
                }
                else if (nums[i] < 90 && nums[i] >= 80)
                {
                    letGrade[i] = 'B';
                }
                else if (nums[i] < 80 && nums[i] >= 70)
                {
                    letGrade[i] = 'C';
                }
                else if (nums[i] < 70 && nums[i] >= 60)
                {
                    letGrade[i] = 'D';
                }
                else if (nums[i] < 60)
                {
                    letGrade[i] = 'F';
                }
            }
            avg = total / 6;

            if (avg >= 90)
            {
                letAvg = 'A';
            }
            else if (avg < 90 && avg >= 80)
            {
                letAvg = 'B';
            }
            else if (avg < 80 && avg >= 70)
            {
                letAvg = 'C';
            }
            else if (avg < 70 && avg >= 60)
            {
                letAvg = 'D';
            }
            else if (avg < 60)
            {
                letAvg = 'F';
            }

            stwrite.WriteLine("Grade\tLetter Grade");
            lbxData.Items.Add("Grade\tLetter Grade");

            for (int i = 0; i < nums.Length; i++)
            {
                stwrite.WriteLine(nums[i] + "\t" + letGrade[i]);
                lbxData.Items.Add(nums[i] + "\t" + letGrade[i]);
            }

            stwrite.WriteLine("Grade Total: " + total);
            lbxData.Items.Add("Grade Total: " + total);
            stwrite.WriteLine("Grade Average: " + avg);
            lbxData.Items.Add("Grade Average: " + avg);
            stwrite.WriteLine("Average letter grade: " + letAvg);
            lbxData.Items.Add("Average letter grade: " + letAvg);

            stwrite.Close();
        }

        private void frmInputOutput_Load(object sender, EventArgs e)
        {
            for (int i = 0; i < nums.Length; i++)
            {
                nums[i] = double.Parse(stread.ReadLine());
                lbxData.Items.Add(nums[i].ToString());                                
            }            
        }
    }
}
