﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HBaethgeACP2_1
{
    public partial class frmLinkList : Form
    {
        LinkedList<String> itemList = new LinkedList<String>();
        Boolean itemFound = false;

        public frmLinkList()
        {
            InitializeComponent();
        }

        private void inputOutputToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form frmInputOutput = new frmInputOutput();
            frmInputOutput.Show();
        }

        private void mouserToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form frmMouser = new frmMouser();
            frmMouser.Show();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form frmAbout = new frmAbout();
            frmAbout.Show();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            itemList.AddLast(tbxItem.Text);
            lbxLinkList.Items.Add("Added: [" + tbxItem.Text + "] to the list.");
        }

        private void btnContains_Click(object sender, EventArgs e)
        {
            foreach(string str in itemList)
            {
                if(str == tbxItem.Text)
                    itemFound = true;                
            }
            
            if (itemFound)
                MessageBox.Show("[" + tbxItem.Text + "] was found in the linkedlist");
            else
                MessageBox.Show("[" + tbxItem.Text + "] was not found in the linkedlist");
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            if (itemList.Remove(tbxItem.Text))
            {                
                lbxLinkList.Items.Add("Removed: [" + tbxItem.Text + "] from list.");
            }
            else
            {
                lbxLinkList.Items.Add("[" + tbxItem.Text + "] was not found in the linkedlist");
            }
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            foreach (string str in itemList)
            {
                lbxLinkList.Items.Add(str);
            }            
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            lbxLinkList.Items.Clear();
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
