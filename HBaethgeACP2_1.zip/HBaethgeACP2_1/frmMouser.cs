﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HBaethgeACP2_1
{
    public partial class frmMouser : Form
    {
        public frmMouser()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void mouse_Click(object sender, MouseEventArgs e)
        {
            lblClickPosit.Text = (e.X + ", " + e.Y);

            if(e.X == 250 && e.Y == 250)
            {
                MessageBox.Show("Awesome Job");
            }
        }
    }
}
