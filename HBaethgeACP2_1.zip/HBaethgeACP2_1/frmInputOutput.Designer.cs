﻿namespace HBaethgeACP2_1
{
    partial class frmInputOutput
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbxData = new System.Windows.Forms.ListBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnGrades = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbxData
            // 
            this.lbxData.FormattingEnabled = true;
            this.lbxData.Location = new System.Drawing.Point(12, 44);
            this.lbxData.Name = "lbxData";
            this.lbxData.Size = new System.Drawing.Size(139, 134);
            this.lbxData.TabIndex = 0;
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(157, 155);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 1;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnGrades
            // 
            this.btnGrades.Location = new System.Drawing.Point(157, 44);
            this.btnGrades.Name = "btnGrades";
            this.btnGrades.Size = new System.Drawing.Size(75, 23);
            this.btnGrades.TabIndex = 2;
            this.btnGrades.Text = "&Grades";
            this.btnGrades.UseVisualStyleBackColor = true;
            this.btnGrades.Click += new System.EventHandler(this.btnGrades_Click);
            // 
            // frmInputOutput
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(244, 218);
            this.Controls.Add(this.btnGrades);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lbxData);
            this.Name = "frmInputOutput";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Input Output";
            this.Load += new System.EventHandler(this.frmInputOutput_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lbxData;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnGrades;
    }
}